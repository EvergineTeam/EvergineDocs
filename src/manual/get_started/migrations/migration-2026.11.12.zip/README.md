# Evergine 2026.11.12 migration scripts

Scripts that update an Evergine **2026.5.26** project to **2026.11.12**. The full guide is
[Update from Evergine 2026.5.26 to Evergine 2026.11.12](https://docs.evergine.com/2026.11.12/manual/get_started/migrations/upgrade_project_2026.11.12.html).

| File | Purpose |
| --- | --- |
| `Update-EvergineProject.ps1` | Updates the whole project: package versions, removed packages, API changes, obsolete YAML keys and feeds. Run this one. |
| `Migrate-BulletToJolt.ps1` | Migrates the physics from Bullet to Jolt. `Update-EvergineProject.ps1` runs it for you when the project uses physics. Keep both files in the same folder. |

## Requirements

- PowerShell 7 (`pwsh`). Windows PowerShell 5.1 is not enough.
- Windows marks downloaded files as coming from the internet. Unblock the zip **before** extracting it
  (`Unblock-File .\migration-2026.11.12.zip`), or unblock both scripts after extracting it
  (`Get-ChildItem *.ps1 | Unblock-File`). If only the first script is unblocked, the physics migration does not run and the
  report shows a `jolt-no-report` warning.

## Usage

Commit your project first. The commands are a dry run unless you add `-Apply`.

```powershell
# Preview the changes
pwsh -File .\Update-EvergineProject.ps1 -ProjectPath C:\Projects\MyGame -TargetVersion 2026.11.12.8

# Apply them and save the report
pwsh -File .\Update-EvergineProject.ps1 -ProjectPath C:\Projects\MyGame -TargetVersion 2026.11.12.8 -Apply -ReportPath port-report.json
```

| Parameter | Use |
| --- | --- |
| `-ProjectPath` | Project folder, `.weproj`, `.sln` or `.csproj`. |
| `-TargetVersion` | Evergine version to move to: `2026.11.12.8`. |
| `-Apply` | Writes the changes. Without it nothing on disk changes. |
| `-NoBackup` | Skips the copies of the original files in `.evergine-update-backup\` and `.bullet-to-jolt-backup\`. |
| `-ReportPath` | Writes the JSON report with every change and finding. |
| `-SwitchWindowsProfileToDirectX12` | Moves the `Windows` profile to DirectX 12, the new default. An existing `Windows.DirectX12` profile becomes `Windows.DirectX11`. |
| `-AddOnVersions @{ 'Evergine.Cesium' = '...' }` | Versions of add-ons that are not part of the engine. Add-ons not listed keep their version and are reported. |
| `-SkipPhysicsMigration` | Does not run `Migrate-BulletToJolt.ps1`. |
| `-StabilizeConstraintChains`, `-TuneVehicleChassis` | Passed to `Migrate-BulletToJolt.ps1`. See the Bullet to Jolt migration guide. |
| `-CleanObsoleteYaml:$false` | Keeps obsolete YAML keys such as `ShadowBias`. |

Exit code: 0 with no warnings, 2 with warnings to review, 1 on error. Running the script again on an updated project
changes nothing.
