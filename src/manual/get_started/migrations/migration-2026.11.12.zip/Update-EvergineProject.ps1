﻿# Copyright © Plain Concepts S.L.U. All rights reserved. Use is subject to license terms.

<#
.SYNOPSIS
Ports an Evergine project from the 2026.5.26.x stable packages to a newer Evergine version (nightly or stable).

.DESCRIPTION
The command is a dry run unless -Apply is supplied. It bumps every Evergine engine package reference
(csproj/props, .weproj, .wespec) to -TargetVersion, removes the Evergine.Bullet packages, migrates
Bullet/Physics3D code and assets to Jolt through Migrate-BulletToJolt.ps1 when the project really uses
physics, rewrites the C#/ImGui/third-party API changes that can be rewritten safely, cleans obsolete YAML
keys, and makes the NuGet / Evergine feeds resolve the target version. Everything it cannot fix is reported
as a finding with file and line.

Files are edited in place as text (encoding, BOM and line endings preserved). The script is idempotent: a
second run over a ported project changes nothing.

.PARAMETER ProjectPath
Project directory, .weproj, .sln or .csproj. Projects without a .weproj (low-level samples) are supported.

.PARAMETER TargetVersion
Target Evergine version, e.g. 2026.11.12.8 (or a nightly such as 2026.11.4.187-nightly).

.PARAMETER AddOnVersions
Hashtable of add-on package id -> version for add-ons that are not produced by the engine
(e.g. @{ 'Evergine.Cesium' = '2026.11.5.180-nightly' }). Add-ons not listed keep their version and get a finding.

.PARAMETER SwitchWindowsProfileToDirectX12
Also moves the 'Windows' profile (weproj GraphicsBackend, Evergine.DirectX11 package, DX11GraphicsContext) to DirectX12,
and turns an existing 'Windows.DirectX12' profile and launcher project into 'Windows.DirectX11'.

.PARAMETER StabilizeConstraintChains
Passed to Migrate-BulletToJolt.ps1: raises the masses and solver iterations of light constraint chains that carry a heavy vehicle.

.PARAMETER TuneVehicleChassis
Passed to Migrate-BulletToJolt.ps1: lowers each migrated vehicle's centre of mass and gives the chassis moderate inertia and angular damping.

.PARAMETER CleanObsoleteYaml
Removes obsolete YAML keys (ShadowBias on lights, SpatialMapping.MaskBits). On by default; pass -CleanObsoleteYaml:$false to keep them.

.PARAMETER JoltScriptPath
Path of Migrate-BulletToJolt.ps1. Defaults to the one next to this script.

.EXAMPLE
./Update-EvergineProject.ps1 -ProjectPath D:\Projects\MyGame -TargetVersion 2026.11.12.8

.EXAMPLE
./Update-EvergineProject.ps1 -ProjectPath D:\Projects\MyGame -TargetVersion 2026.11.12.8 -Apply -ReportPath port-report.json
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateNotNullOrEmpty()]
    [string] $ProjectPath,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d+\.\d+\.\d+\.\d+(-[A-Za-z0-9-]+)?$')]
    [string] $TargetVersion,

    [hashtable] $AddOnVersions = @{},

    [switch] $Apply,

    [switch] $NoBackup,

    [switch] $SkipPhysicsMigration,

    [switch] $SwitchWindowsProfileToDirectX12,

    [switch] $StabilizeConstraintChains,

    [switch] $TuneVehicleChassis,

    [switch] $CleanObsoleteYaml = $true,

    [string] $JoltScriptPath,

    [string] $ReportPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
trap { Write-Host "Update-EvergineProject.ps1: $($_.Exception.Message) at line $($_.InvocationInfo.ScriptLineNumber)"; exit 1 }

$script:Findings = New-Object System.Collections.ArrayList
$script:ChangedFiles = New-Object 'System.Collections.Generic.List[string]'
$script:ScannedFiles = 0
$script:ChangeCount = 0
$script:Backup = $null

# NuGet ids produced by the engine (EvergineCoreDependencies.NuGetWhiteList + packages the nightly also publishes).
$script:CorePackages = @(
    'Evergine.Android', 'Evergine.AndroidView', 'Evergine.ARMobile', 'Evergine.Assets', 'Evergine.Avalonia',
    'Evergine.CodeScenes', 'Evergine.Common', 'Evergine.Components', 'Evergine.DirectX11', 'Evergine.DirectX12',
    'Evergine.Editor.Extension', 'Evergine.Forms', 'Evergine.Framework', 'Evergine.GTK', 'Evergine.HLSLEverywhere',
    'Evergine.ImGui', 'Evergine.iOS', 'Evergine.iOSView', 'Evergine.Mathematics', 'Evergine.Metal', 'Evergine.Mocks',
    'Evergine.Networking', 'Evergine.OpenAL', 'Evergine.OpenGL', 'Evergine.OpenGL.Common', 'Evergine.OpenGLES',
    'Evergine.OpenVR', 'Evergine.OpenXR', 'Evergine.Platform', 'Evergine.Packages.Targets',
    'Evergine.Serialization.Converters', 'Evergine.SDL', 'Evergine.Targets', 'Evergine.Vuforia', 'Evergine.VuforiaSharp',
    'Evergine.Vulkan', 'Evergine.WPF', 'Evergine.Web', 'Evergine.WebGL', 'Evergine.WebGPU', 'Evergine.WinUI', 'Evergine.XAudio2'
)
$script:CorePackagePattern = '^Evergine\.(Runtimes|Targets)\.[A-Za-z]+$'

# Packages that no longer exist in the target versions.
$script:RemovedPackagePattern = '^Evergine\.(Bullet|LibBulletc(\.Natives(\.Wasm)?)?|BulletSharpPInvoke)$'

# Third-party pins that must be at least the version the engine packages require.
$script:ThirdPartyMinimums = @{
    'Microsoft.AspNetCore.Components.WebAssembly'           = '10.0.13'
    'Microsoft.AspNetCore.Components.WebAssembly.DevServer' = '10.0.13'
    'Microsoft.AspNetCore.Components.WebAssembly.Server'    = '10.0.13'
    'SkiaSharp'                                             = '4.153.1'
    'SkiaSharp.NativeAssets.Win32'                          = '4.153.1'
    'SkiaSharp.NativeAssets.Linux.NoDependencies'           = '4.153.1'
    'SkiaSharp.NativeAssets.macOS'                          = '4.153.1'
    'SkiaSharp.NativeAssets.WebAssembly'                    = '4.153.1'
    'Avalonia'                                              = '12.1.4'
    'Avalonia.Desktop'                                      = '12.1.4'
    'Avalonia.Themes.Fluent'                                = '12.1.4'
    'Avalonia.Fonts.Inter'                                  = '12.1.4'
    'Microsoft.WindowsAppSDK'                               = '2.5.1'
    'Evergine.Bindings.Imgui'                               = '2026.10.1.34'
    'Evergine.Bindings.Vulkan'                              = '2026.10.1.27'
    'Evergine.Bindings.OpenXR'                              = '2026.11.4.23'
}

# Avalonia.Diagnostics has no 12.x release; the Avalonia template drops it when it moves to Avalonia 12.
$script:AvaloniaDiagnosticsPattern = '(?ms)^[ \t]*(?:<!--[^\r\n]*Avalonia\.Diagnostics[^\r\n]*-->[ \t]*\r?\n[ \t]*)?<PackageReference\b[^>]*\bInclude="Avalonia\.Diagnostics"[^>]*?(?:/>|(?<!/)>.*?</PackageReference>)[ \t]*\r?\n?'

$script:NightlyNuGetFeed = 'https://pkgs.dev.azure.com/plainconcepts/Evergine.Nightly/_packaging/Evergine.NightlyBuilds/nuget/v3/index.json'
$script:NightlyBlobSource = 'https://everginestudio.blob.core.windows.net/nightly'
$script:StableBlobSource = 'https://everginestudio.blob.core.windows.net/stable'

$script:ExcludedDirs = @('.git', '.vs', 'bin', 'obj', 'node_modules', '.bullet-to-jolt-backup', '.evergine-update-backup', '.evergine', 'wwwroot')

function Add-Finding {
    param([string] $Severity, [string] $Code, [string] $File, [int] $Line, [string] $Message)
    [void]$script:Findings.Add([pscustomobject]@{ Severity = $Severity; Code = $Code; File = $File; Line = $Line; Message = $Message })
}

function Get-LineNumber {
    param([string] $Text, [int] $Index)
    if ($Index -le 0) { return 1 }
    return ([regex]::Matches($Text.Substring(0, [Math]::Min($Index, $Text.Length)), "`n").Count + 1)
}

function Get-RelativePath {
    param([string] $Path)
    $full = [System.IO.Path]::GetFullPath($Path)
    if ($full.StartsWith($script:Root, [StringComparison]::OrdinalIgnoreCase)) { return $full.Substring($script:Root.Length).TrimStart('\', '/') }
    return $full
}

function Read-TextFile {
    param([string] $Path)
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    $hasBom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    $text = [System.Text.Encoding]::UTF8.GetString($bytes, $(if ($hasBom) { 3 } else { 0 }), $bytes.Length - $(if ($hasBom) { 3 } else { 0 }))
    $eol = if ($text -match "`r`n") { "`r`n" } else { "`n" }
    return [pscustomobject]@{ Path = $Path; Text = $text; Bom = $hasBom; Eol = $eol }
}

function Save-TextFile {
    param($File, [string] $NewText, [string] $What)
    if ($NewText -eq $File.Text) { return $false }
    $rel = Get-RelativePath $File.Path
    $script:ChangeCount++
    if (-not $script:ChangedFiles.Contains($rel)) { $script:ChangedFiles.Add($rel) }
    Write-Verbose "$($(if ($Apply) { 'Updated' } else { 'Would update' })) $rel ($What)"
    if (-not $Apply) { $File.Text = $NewText; return $true }
    if (-not $NoBackup) {
        if (-not $script:Backup) {
            $script:Backup = Join-Path $script:Root ('.evergine-update-backup\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
        }
        $target = Join-Path $script:Backup $rel
        if (-not (Test-Path $target)) {
            New-Item -ItemType Directory -Force (Split-Path $target) | Out-Null
            Copy-Item $File.Path $target
        }
    }
    $enc = New-Object System.Text.UTF8Encoding($File.Bom)
    [System.IO.File]::WriteAllText($File.Path, $NewText, $enc)
    $File.Text = $NewText
    return $true
}

function Get-ProjectFiles {
    param([string[]] $Include)
    Get-ChildItem -Path $script:Root -Recurse -File -Include $Include | Where-Object {
        $rel = Get-RelativePath $_.FullName
        $parts = $rel -split '[\\/]'
        -not ($parts | Where-Object { $script:ExcludedDirs -contains $_ })
    } | Sort-Object FullName
}

function Compare-NuGetVersion {
    # Returns -1, 0, 1 comparing a and b as NuGet versions (numeric parts then prerelease label, no label > label).
    param([string] $A, [string] $B)
    $pa = $A -split '-', 2; $pb = $B -split '-', 2
    $na = $pa[0] -split '\.' | ForEach-Object { [int]$_ }
    $nb = $pb[0] -split '\.' | ForEach-Object { [int]$_ }
    for ($i = 0; $i -lt [Math]::Max($na.Count, $nb.Count); $i++) {
        $x = if ($i -lt $na.Count) { $na[$i] } else { 0 }
        $y = if ($i -lt $nb.Count) { $nb[$i] } else { 0 }
        if ($x -ne $y) { return [Math]::Sign($x - $y) }
    }
    $la = if ($pa.Count -gt 1) { $pa[1] } else { '' }
    $lb = if ($pb.Count -gt 1) { $pb[1] } else { '' }
    if ($la -eq $lb) { return 0 }
    if ($la -eq '') { return 1 }
    if ($lb -eq '') { return -1 }
    return [string]::CompareOrdinal($la, $lb)
}

function Test-CorePackage {
    param([string] $Id)
    return ($script:CorePackages -contains $Id) -or ($Id -match $script:CorePackagePattern)
}

function Split-TopLevelArgs {
    # Splits the text between the parentheses of a call at top-level commas.
    param([string] $ArgText)
    $args = New-Object 'System.Collections.Generic.List[string]'
    $depth = 0; $start = 0; $inString = $false
    for ($i = 0; $i -lt $ArgText.Length; $i++) {
        $c = $ArgText[$i]
        if ($inString) { if ($c -eq '\') { $i++ } elseif ($c -eq '"') { $inString = $false }; continue }
        switch ($c) {
            '"' { $inString = $true }
            '(' { $depth++ }
            '[' { $depth++ }
            '{' { $depth++ }
            ')' { $depth-- }
            ']' { $depth-- }
            '}' { $depth-- }
            ',' { if ($depth -eq 0) { $args.Add($ArgText.Substring($start, $i - $start)); $start = $i + 1 } }
        }
    }
    $args.Add($ArgText.Substring($start))
    return $args
}

function Find-CallEnd {
    # Index of the parenthesis that closes the call whose opening parenthesis is at $Open.
    param([string] $Text, [int] $Open)
    $depth = 0; $inString = $false
    for ($i = $Open; $i -lt $Text.Length; $i++) {
        $c = $Text[$i]
        if ($inString) { if ($c -eq '\') { $i++ } elseif ($c -eq '"') { $inString = $false }; continue }
        if ($c -eq '"') { $inString = $true; continue }
        if ($c -eq '(') { $depth++ } elseif ($c -eq ')') { $depth--; if ($depth -eq 0) { return $i } }
    }
    return -1
}

# --------------------------------------------------------------------------------------------------------------
# Root resolution
# --------------------------------------------------------------------------------------------------------------

$inputPath = (Resolve-Path $ProjectPath).Path
if (Test-Path $inputPath -PathType Container) {
    $script:Root = $inputPath
} else {
    $ext = [System.IO.Path]::GetExtension($inputPath).ToLowerInvariant()
    if ($ext -notin '.weproj', '.sln', '.slnx', '.csproj') { throw "ProjectPath must be a project directory, .sln, .slnx, .csproj or .weproj file" }
    $dir = Split-Path $inputPath
    $script:Root = $dir
    while ($dir -and -not (Get-ChildItem $dir -Filter '*.weproj' -File -ErrorAction SilentlyContinue)) {
        $parent = Split-Path $dir
        if (-not $parent -or $parent -eq $dir) { break }
        $dir = $parent
        if (Get-ChildItem $dir -Filter '*.weproj' -File -ErrorAction SilentlyContinue) { $script:Root = $dir }
    }
}
$script:Root = [System.IO.Path]::GetFullPath($script:Root).TrimEnd('\', '/')
if ((Split-Path $script:Root -Qualifier -ErrorAction SilentlyContinue) -eq $script:Root -or $script:Root -match '^[A-Za-z]:\\?$') { throw "Refusing to scan and edit an entire drive" }

if (-not $JoltScriptPath) { $JoltScriptPath = Join-Path $PSScriptRoot 'Migrate-BulletToJolt.ps1' }
$isNightly = $TargetVersion -match '-nightly$'

Write-Host "Update-EvergineProject: $script:Root -> $TargetVersion ($(if ($Apply) { 'APPLY' } else { 'dry run' }))"

$weprojFiles = @(Get-ProjectFiles '*.weproj')
$csprojFiles = @(Get-ProjectFiles '*.csproj', '*.props', '*.targets')
$slnFiles = @(Get-ProjectFiles '*.sln')
$csFiles = @(Get-ProjectFiles '*.cs' | Where-Object { $_.Name -ne 'EvergineContent.cs' })
$yamlFiles = @(Get-ProjectFiles '*.wescene', '*.weprefab')
$wespecFiles = @(Get-ProjectFiles '*.wespec')
$script:ScannedFiles = $weprojFiles.Count + $csprojFiles.Count + $slnFiles.Count + $csFiles.Count + $yamlFiles.Count + $wespecFiles.Count
$hasWeproj = $weprojFiles.Count -gt 0
if (-not $hasWeproj) { Add-Finding 'Info' 'low-level-project' '' 0 'No .weproj found: only package versions, feeds and C# rewrites are applied.' }

# Detected source version = most frequent core package version.
$versionCounts = @{}
foreach ($f in $csprojFiles) {
    foreach ($m in [regex]::Matches((Get-Content -Raw $f.FullName), '<PackageReference\b[^>]*\bInclude="([^"]+)"[^>]*\bVersion="([^"]+)"')) {
        if (Test-CorePackage $m.Groups[1].Value) { $v = $m.Groups[2].Value; $versionCounts[$v] = 1 + $(if ($versionCounts.ContainsKey($v)) { $versionCounts[$v] } else { 0 }) }
    }
}
$detectedVersion = ($versionCounts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 1).Key
Write-Host "Detected engine version: $detectedVersion"

# --------------------------------------------------------------------------------------------------------------
# Physics usage detection
# --------------------------------------------------------------------------------------------------------------

$physicsInAssets = @($yamlFiles | Where-Object { (Get-Content -Raw $_.FullName) -match '!Evergine\.(Framework\.Physics3D|Bullet)\.' })
$physicsInCode = @($csFiles | Where-Object {
    $t = Get-Content -Raw $_.FullName
    $stripped = $t -replace 'this\.Managers\.AddManager\(new\s+(global::)?Evergine\.Bullet\.BulletPhysicManager3D\(\)\s*(\{[^}]*\})?\);', '' -replace 'using Evergine\.Bullet;', '' -replace 'using Evergine\.Framework\.Physics3D;', ''
    $stripped -match '\b(Physics3D|PhysicManager3D|BulletPhysicManager3D|RigidBody3D|StaticBody3D|\w+Collider3D|\w+Joint3D|PhysicVehicle3D|PhysicWheel3D|CollisionCategory3D|HitResult3D|CollisionInfo3D|CharacterController3D)\b'
})
$usesPhysics = ($physicsInAssets.Count + $physicsInCode.Count) -gt 0
Write-Host "Physics usage: $(if ($usesPhysics) { "yes ($($physicsInAssets.Count) assets, $($physicsInCode.Count) source files)" } else { 'no (Bullet manager only)' })"

# --------------------------------------------------------------------------------------------------------------
# 1. Package versions, removed packages, third-party minimums (csproj/props/targets)
# --------------------------------------------------------------------------------------------------------------

foreach ($f in $csprojFiles) {
    $file = Read-TextFile $f.FullName
    $rel = Get-RelativePath $f.FullName
    $text = $file.Text

    $text = [regex]::Replace($text, '<(PackageReference|PackageVersion)\b[^>]*?/?>', {
        param($m)
        $el = $m.Value
        $idMatch = [regex]::Match($el, '\b(?:Include|Update)="([^"]+)"')
        if (-not $idMatch.Success) { return $el }
        $id = $idMatch.Groups[1].Value
        $verMatch = [regex]::Match($el, '\bVersion="([^"]+)"')
        if (-not $verMatch.Success) {
            if (Test-CorePackage $id) { Add-Finding 'Warning' 'package-without-version' $rel (Get-LineNumber $file.Text $m.Index) "$id has no Version attribute (central package management?); not updated." }
            return $el
        }
        $current = $verMatch.Groups[1].Value
        if ($current -notmatch '^\d') { return $el }   # MSBuild property versions ($(AvaloniaVersion)) are left alone
        $target = $null
        if (Test-CorePackage $id) { $target = $TargetVersion }
        elseif ($AddOnVersions.ContainsKey($id)) { $target = [string]$AddOnVersions[$id] }
        elseif ($id -match $script:RemovedPackagePattern) { return $el }
        elseif ($script:ThirdPartyMinimums.ContainsKey($id)) {
            $isNet10 = $file.Text -match '<TargetFramework(s)?>[^<]*net10\.0'
            if (($id -notlike 'Microsoft.AspNetCore.*' -or $isNet10) -and (Compare-NuGetVersion $current $script:ThirdPartyMinimums[$id]) -lt 0) {
                $target = $script:ThirdPartyMinimums[$id]
                Add-Finding 'Info' 'third-party-bump' $rel (Get-LineNumber $file.Text $m.Index) "$id $current -> $target (minimum required by the Evergine $TargetVersion packages)."
            }
        }
        elseif ($id -like 'Evergine.*' -and $id -notlike 'Evergine.Bindings.*') {
            Add-Finding 'Warning' 'addon-version-not-mapped' $rel (Get-LineNumber $file.Text $m.Index) "$id $current is not an engine package; pass -AddOnVersions to update it (an add-on built against $detectedVersion may not load on $TargetVersion)."
        }
        if ($target -and $target -ne $current) { return $el.Substring(0, $verMatch.Groups[1].Index) + $target + $el.Substring($verMatch.Groups[1].Index + $verMatch.Groups[1].Length) }
        return $el
    })

    # Removed packages: whole element (self-closing or with children) and the empty ItemGroups left behind.
    $removedPattern = '(?ms)^[ \t]*<(PackageReference|PackageVersion|Reference)\b[^>]*\b(?:Include|Update)="(Evergine\.(?:Bullet|LibBulletc[^"]*|BulletSharpPInvoke))"[^>]*?(?:/>|(?<!/)>.*?</\1>)[ \t]*\r?\n?'
    foreach ($m in [regex]::Matches($text, $removedPattern)) { Add-Finding 'Info' 'bullet-package-removed' $rel (Get-LineNumber $text $m.Index) "Removed $($m.Groups[2].Value) reference." }
    $text = [regex]::Replace($text, $removedPattern, '')
    $text = [regex]::Replace($text, '(?ms)^[ \t]*<ProjectReference\b[^>]*Include="[^"]*Evergine\.Bullet[^"]*"[^>]*/>[ \t]*\r?\n?', '')
    $text = [regex]::Replace($text, '(?ms)^[ \t]*<ItemGroup(\s[^>]*)?>\s*</ItemGroup>[ \t]*\r?\n?', '')

    if ($text -match '\bEvergine\.(Bullet|LibBulletc|BulletSharpPInvoke)') { Add-Finding 'Warning' 'bullet-reference-remains' $rel (Get-LineNumber $text $text.IndexOf('Evergine.Bullet')) 'A Bullet reference is still present after the rewrite.' }

    # Version properties used by the Avalonia/WinUI templates
    $text = [regex]::Replace($text, '<AvaloniaVersion>11\.[0-9.]+</AvaloniaVersion>', '<AvaloniaVersion>12.1.4</AvaloniaVersion>')
    if ($text -match '<AvaloniaVersion>12\.|Include="Avalonia"\s+Version="12\.' -and $text -match $script:AvaloniaDiagnosticsPattern) {
        $text = [regex]::Replace($text, $script:AvaloniaDiagnosticsPattern, '')
        Add-Finding 'Info' 'avalonia-diagnostics-removed' $rel 0 'Removed Avalonia.Diagnostics: it has no Avalonia 12 release (the Avalonia template no longer references it).'
    }

    # Android template now targets net10.0
    $text = [regex]::Replace($text, '<TargetFramework>net9\.0-android</TargetFramework>', '<TargetFramework>net10.0-android</TargetFramework>')

    if ($SwitchWindowsProfileToDirectX12 -and $f.Name -match '\.Windows\.csproj$' -and $text -match 'Include="Evergine\.DirectX11"') {
        $text = $text -replace 'Include="Evergine\.DirectX11"', 'Include="Evergine.DirectX12"'
    }

    Save-TextFile $file $text 'packages' | Out-Null
}

# --------------------------------------------------------------------------------------------------------------
# 2. Solutions: drop Evergine.Bullet project entries (template <local-only> leftovers)
# --------------------------------------------------------------------------------------------------------------

foreach ($f in $slnFiles) {
    $file = Read-TextFile $f.FullName
    $text = $file.Text
    $guids = [regex]::Matches($text, '(?m)^Project\("\{[^}]+\}"\) = "Evergine\.Bullet",[^\r\n]*\{([0-9A-Fa-f-]+)\}"\s*\r?\nEndProject\r?\n') | ForEach-Object { $_.Groups[1].Value }
    foreach ($g in $guids) {
        $text = [regex]::Replace($text, '(?m)^Project\("\{[^}]+\}"\) = "Evergine\.Bullet",[^\r\n]*\r?\nEndProject\r?\n', '')
        $text = [regex]::Replace($text, "(?m)^[ \t]*\{$g\}[^\r\n]*\r?\n", '')
        Add-Finding 'Info' 'bullet-sln-entry-removed' (Get-RelativePath $f.FullName) 0 "Removed Evergine.Bullet project {$g} from the solution."
    }
    Save-TextFile $file $text 'solution' | Out-Null
}

# --------------------------------------------------------------------------------------------------------------
# 3. weproj / wespec
# --------------------------------------------------------------------------------------------------------------

foreach ($f in $weprojFiles) {
    $file = Read-TextFile $f.FullName
    $rel = Get-RelativePath $f.FullName
    $text = $file.Text
    $text = [regex]::Replace($text, '(?m)(^\s*- Id: (\S+)\r?\n(?:\s*LocalPath: [^\r\n]*\r?\n)?\s*Version: )(\S+)', {
        param($m)
        $id = $m.Groups[2].Value; $current = $m.Groups[3].Value
        $target = $null
        if ($id -eq 'Evergine.Core') { $target = $TargetVersion }
        elseif ($AddOnVersions.ContainsKey($id)) { $target = [string]$AddOnVersions[$id] }
        elseif ($current -ne 'null') { Add-Finding 'Warning' 'addon-version-not-mapped' $rel (Get-LineNumber $text $m.Index) "weproj add-on $id $current kept; pass -AddOnVersions to update it." }
        if ($target -and $target -ne $current) { return $m.Groups[1].Value + $target }
        return $m.Value
    })
    if ($text -notmatch '(?m)^Parameters:') {
        $text = $text.TrimEnd("`r", "`n") + $file.Eol + 'Parameters:' + $file.Eol + '  MaxSkinningWeights: 4' + $file.Eol + '  SparseMorphTargets: false'
        Add-Finding 'Info' 'weproj-parameters-added' $rel 0 'Added the default Parameters block.'
    }
    if ($SwitchWindowsProfileToDirectX12) {
        # Only the profile whose Name is exactly 'Windows' (entries are indented 4 spaces; a new entry starts with '  - ').
        $text = [regex]::Replace($text, '(?m)(GraphicsBackend: )DirectX11(\r?\n(?:[ \t]{4}[^\r\n]*\r?\n)*?[ \t]{4}Name: Windows\r?$)', '${1}DirectX12$2')
    }
    Save-TextFile $file $text 'weproj' | Out-Null
}

foreach ($f in $wespecFiles) {
    $file = Read-TextFile $f.FullName
    $text = [regex]::Replace($file.Text, '(Evergine\.(?:Framework|Common|Components|Mathematics) )\d+\.\d+\.\d+\.\d+(-[A-Za-z0-9-]+)?', "`${1}$TargetVersion")
    Save-TextFile $file $text 'wespec' | Out-Null
}

# --------------------------------------------------------------------------------------------------------------
# 4. Physics: Bullet manager removal (no physics) or Jolt migration (physics)
# --------------------------------------------------------------------------------------------------------------

$managerPattern = '(?m)^[ \t]*this\.Managers\.AddManager\(new\s+(?:global::)?(?:Evergine\.Bullet\.)?BulletPhysicManager3D\(\)\s*(?:\{[^}]*\})?\);[ \t]*\r?\n?'
if (-not $usesPhysics -or $SkipPhysicsMigration) {
    foreach ($f in $csFiles) {
        $file = Read-TextFile $f.FullName
        $text = $file.Text
        if ($text -notmatch 'BulletPhysicManager3D|using Evergine\.Bullet;') { continue }
        $text = [regex]::Replace($text, $managerPattern, '')
        $text = [regex]::Replace($text, '(?m)^using Evergine\.Bullet;[ \t]*\r?\n', '')
        Add-Finding 'Info' 'bullet-manager-removed' (Get-RelativePath $f.FullName) 0 'Removed the BulletPhysicManager3D registration (the project uses no physics).'
        Save-TextFile $file $text 'bullet manager' | Out-Null
    }
} else {
    if (-not (Test-Path $JoltScriptPath)) { throw "Migrate-BulletToJolt.ps1 not found at $JoltScriptPath" }
    $joltReport = Join-Path ([System.IO.Path]::GetTempPath()) ("jolt-" + [guid]::NewGuid().ToString('N') + '.json')
    $joltArgs = @('-NoProfile', '-File', $JoltScriptPath, '-ProjectPath', $script:Root, '-ReportPath', $joltReport)
    if ($Apply) { $joltArgs += '-Apply' }
    # The physics migration keeps its own backup (.bullet-to-jolt-backup\<timestamp>) of the files it changes.
    if ($NoBackup) { $joltArgs += '-NoBackup' }
    if ($StabilizeConstraintChains) { $joltArgs += '-StabilizeConstraintChains' }
    if ($TuneVehicleChassis) { $joltArgs += '-TuneVehicleChassis' }
    Write-Host "Running Migrate-BulletToJolt.ps1 ($(if ($Apply) { 'apply' } else { 'dry run' }))..."
    & pwsh @joltArgs *> (Join-Path ([System.IO.Path]::GetTempPath()) 'jolt-output.log')
    if (Test-Path $joltReport) {
        $jr = Get-Content -Raw $joltReport | ConvertFrom-Json
        foreach ($cf in @($jr.ChangedFiles)) { if ($cf -and -not $script:ChangedFiles.Contains($cf)) { $script:ChangedFiles.Add($cf); $script:ChangeCount++ } }
        foreach ($fi in @($jr.Findings)) { Add-Finding $fi.Severity ('jolt:' + $fi.Code) $fi.File ([int]$fi.Line) $fi.Message }
        Remove-Item $joltReport -ErrorAction SilentlyContinue
    } else {
        Add-Finding 'Warning' 'jolt-no-report' '' 0 'Migrate-BulletToJolt.ps1 produced no report; see jolt-output.log in TEMP.'
    }

    # Scenes with Jolt components but no PhysicsManager (neither in YAML nor registered in code).
    $managerInCode = @($csFiles | Where-Object { (Get-Content -Raw $_.FullName) -match 'new\s+(global::)?(Evergine\.Framework\.Physics\.)?PhysicsManager\s*\(' }).Count -gt 0
    if (-not $managerInCode) {
        foreach ($f in @(Get-ProjectFiles '*.wescene')) {
            $file = Read-TextFile $f.FullName
            $text = $file.Text
            if ($text -notmatch '!Evergine\.Framework\.Physics\.' -or $text -match '!Evergine\.Framework\.Physics\.PhysicsManager,') { continue }
            $block = '  - !Evergine.Framework.Physics.PhysicsManager,Evergine.Framework' + $file.Eol + '    Id: ' + [guid]::NewGuid().ToString() + $file.Eol + '    IsEnabled: true'
            if ($text -match '(?m)^Managers:') {
                $text = $text.TrimEnd("`r", "`n") + $file.Eol + $block
            } else {
                $text = $text.TrimEnd("`r", "`n") + $file.Eol + 'Managers:' + $file.Eol + $block
            }
            Add-Finding 'Info' 'physics-manager-added' (Get-RelativePath $f.FullName) 0 'Added the PhysicsManager to the scene Managers.'
            Save-TextFile $file $text 'physics manager' | Out-Null
        }
    }
}

# --------------------------------------------------------------------------------------------------------------
# 5. C# rewrites
# --------------------------------------------------------------------------------------------------------------

$manualPatterns = @(
    @{ Pattern = '\bRayStep\b'; Message = 'Evergine.Mathematics.RayStep was removed; use Ray + length (or copy the old struct from tag 2026.5.26.2553).' }
    @{ Pattern = '\bEnvironmentComponent\b'; Message = 'EnvironmentComponent was removed; configure Managers.EnvironmentManager (IBLReflectionProbe, IntensityMultiplier).' }
    @{ Pattern = '\bShadowMapComponent\b'; Message = 'ShadowMapComponent was removed; configure Managers.FindManager<ShadowMapManager>().' }
    @{ Pattern = '\b(ContactTestBehavior|SetCollisionEvents)\b'; Message = 'Removed with Jolt; use PhysicsBody.CollisionStarted/Updated/Ended or PhysicsManager overlap queries.' }
    @{ Pattern = '\.(SkyTint|GroundColor)\b'; Message = 'AtmosphericMaterial.SkyTint/GroundColor were removed.' }
    @{ Pattern = '\.PerObject_WorldViewProj\b'; Message = 'SkyboxMaterial.PerObject_WorldViewProj was removed.' }
    @{ Pattern = '\.SourceEntityId\b'; Message = 'ParticlesComponent.SourceEntityId was removed; use SourceEntity (Entity).' }
    @{ Pattern = '\.ShadowBias\b'; Message = 'Light.ShadowBias is obsolete and ignored; use ShadowDepthBias/ShadowNormalBias (texel units, do not copy the old value).' }
    @{ Pattern = '\bRayStepJsonConverter\b'; Message = 'RayStepJsonConverter was removed.' }
    @{ Pattern = '\bigSetColorEditOptions\b'; Message = 'igSetColorEditOptions was removed in Dear ImGui 1.92.9b; set ImGuiIO.ConfigColorEditFlags instead.' }
    @{ Pattern = '\(ImPlotProp\)\s*\d+'; Message = 'ImPlotProp values were renumbered; use the named member.' }
    @{ Pattern = '\.AttachDevTools\s*\('; Message = 'Avalonia.Diagnostics (AttachDevTools) has no Avalonia 12 release; remove the call or use the Avalonia 12 developer tools.' }
)

function Rename-TypedMembers {
    # Renames members only on identifiers declared with the given type in the same file (fields, properties, locals, parameters, var = new T).
    param([string] $Text, [string] $TypeName, [hashtable] $Map)
    $names = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($m in [regex]::Matches($Text, "\b$TypeName\??\s+(\w+)\b")) { [void]$names.Add($m.Groups[1].Value) }
    foreach ($m in [regex]::Matches($Text, "\bvar\s+(\w+)\s*=\s*new\s+(?:[\w.]+\.)?$TypeName\b")) { [void]$names.Add($m.Groups[1].Value) }
    foreach ($n in $names) {
        foreach ($old in $Map.Keys) { $Text = [regex]::Replace($Text, "\b(this\.)?$([regex]::Escape($n))\.$old\b", "`${1}$n.$($Map[$old])") }
    }
    return $Text
}

$imguiSwaps = @(
    @{ Name = 'ImDrawList_AddRect'; Count = 7 }
    @{ Name = 'ImDrawList_AddPolyline'; Count = 6 }
    @{ Name = 'ImDrawList_PathStroke'; Count = 4 }
)

function Invoke-ImGuiArgumentSwap {
    param([string] $Text, [string] $Name, [int] $Count, [string] $Rel)
    $pos = 0
    while (($idx = $Text.IndexOf($Name + '(', $pos, [StringComparison]::Ordinal)) -ge 0) {
        $open = $idx + $Name.Length
        $close = Find-CallEnd $Text $open
        if ($close -lt 0) { break }
        $inner = $Text.Substring($open + 1, $close - $open - 1)
        $args = Split-TopLevelArgs $inner
        $pos = $close
        if ($args.Count -ne $Count) { continue }
        $last = $args[$args.Count - 1].Trim(); $prev = $args[$args.Count - 2].Trim()
        $lastIsFlags = $last -match 'ImDrawFlags|[Ff]lags'
        $prevIsFlags = $prev -match 'ImDrawFlags|[Ff]lags'
        if ($prevIsFlags -and -not $lastIsFlags) {
            $args[$args.Count - 2] = $args[$args.Count - 1]; $args[$args.Count - 1] = ' ' + $prev
            $newInner = [string]::Join(',', $args)
            $Text = $Text.Substring(0, $open + 1) + $newInner + $Text.Substring($close)
            Add-Finding 'Info' 'imgui-argument-order' $Rel (Get-LineNumber $Text $idx) "${Name}: swapped (flags, thickness) to (thickness, flags)."
        } elseif (-not $prevIsFlags -and -not $lastIsFlags) {
            Add-Finding 'Warning' 'imgui-argument-order-ambiguous' $Rel (Get-LineNumber $Text $idx) "${Name}: cannot tell flags from thickness (both numeric); the new order is (..., thickness, flags)."
        }
    }
    return $Text
}

foreach ($f in $csFiles) {
    $file = Read-TextFile $f.FullName
    $rel = Get-RelativePath $f.FullName
    $text = $file.Text

    if ($text -match '\bOnDetach\s*\(\s*\)') {
        if ($text -match 'void\s+OnDetached\s*\(') { Add-Finding 'Warning' 'ondetach-merge-required' $rel (Get-LineNumber $text $text.IndexOf('OnDetach(')) 'Class overrides both OnDetach() and OnDetached(); merge the bodies by hand.' }
        else { $text = [regex]::Replace($text, '\bOnDetach\s*\(\s*\)', 'OnDetached()'); Add-Finding 'Info' 'ondetach-renamed' $rel 0 'OnDetach() -> OnDetached().' }
    }
    if ($text -match '\.RegisterType<') {
        # RegisterType<T>(bool singleton) -> Register<T>(reuse: bool); the first parameter of Register<T> is now the factory.
        $text = [regex]::Replace($text, '\.RegisterType<([^<>()]+(?:<[^<>()]*>)?)>\(\s*(?:singleton\s*:\s*)?([^(),]+?)\s*\)', '.Register<$1>(reuse: $2)')
        $text = $text -replace '\.RegisterType<', '.Register<'
        Add-Finding 'Info' 'container-register' $rel 0 'Container.RegisterType<T>(singleton) -> Register<T>(reuse: singleton).'
    }
    if ($text -match '\.RegisterFactoryDelegate') { $text = [regex]::Replace($text, '\.RegisterFactoryDelegate(<[^>]+>)?\(', '.Register$1('); Add-Finding 'Info' 'container-register' $rel 0 'Container.RegisterFactoryDelegate -> Register.' }
    if ($text -match '\bBoundingOrientedBox\b') {
        $text = Rename-TypedMembers $text 'BoundingOrientedBox' @{ 'Minimum' = 'Min'; 'Maximum' = 'Max' }
        foreach ($m in [regex]::Matches($text, '\.(Minimum|Maximum)\b')) { Add-Finding 'Warning' 'manual-edit-required' $rel (Get-LineNumber $text $m.Index) "If this is a BoundingOrientedBox, $($m.Groups[1].Value) was removed; use $($m.Groups[1].Value.Substring(0, 3))." }
    }
    if ($text -match '\bWavFileWriter\b') {
        $text = Rename-TypedMembers $text 'WavFileWriter' @{ 'WriteData' = 'WriteSamples' }
        foreach ($m in [regex]::Matches($text, '\.WriteData\(')) { Add-Finding 'Warning' 'manual-edit-required' $rel (Get-LineNumber $text $m.Index) 'If this is a WavFileWriter, WriteData was removed; use WriteSamples.' }
    }
    $text = [regex]::Replace($text, '\.AddTouchLocation\(([^,]+),\s*TouchLocationState\.\w+\s*,', '.AddTouchLocation($1,')
    $text = $text -replace '->CmdListsCount\b', '->CmdLists.Size' -replace '(?<=\w)\.CmdListsCount\b', '.CmdLists.Size'
    if ($text -match '\(ImDrawFlags\)\s*1\b') { $text = [regex]::Replace($text, '\(ImDrawFlags\)\s*1\b', 'ImDrawFlags.Closed'); Add-Finding 'Info' 'imgui-closed-flag' $rel 0 '(ImDrawFlags)1 -> ImDrawFlags.Closed.' }
    if ($text -match 'ImguiNative|ImDrawList_') {
        foreach ($s in $imguiSwaps) { $text = Invoke-ImGuiArgumentSwap $text $s.Name $s.Count $rel }
        foreach ($m in [regex]::Matches($text, '\((ImGuiCol|ImGuiStyleVar|ImGuiColorEditFlags)\)\s*\d+')) { Add-Finding 'Warning' 'imgui-enum-literal' $rel (Get-LineNumber $text $m.Index) "$($m.Value): enum values were renumbered in Dear ImGui 1.92.9b; use the named member." }
    }
    foreach ($p in $manualPatterns) {
        foreach ($m in [regex]::Matches($text, $p.Pattern)) { Add-Finding 'Warning' 'manual-edit-required' $rel (Get-LineNumber $text $m.Index) $p.Message }
    }
    if (-not $hasWeproj) {
        foreach ($m in [regex]::Matches($text, '(?:==|!=)\s*AccelerationStructureFlags\.\w+|\(int\)\s*AccelerationStructureFlags|AccelerationStructureFlags\)\s*\d')) { Add-Finding 'Warning' 'acceleration-structure-flags' $rel (Get-LineNumber $text $m.Index) 'AccelerationStructureFlags values are bit flags now; review this comparison/cast.' }
    }
    Save-TextFile $file $text 'C#' | Out-Null
}

# --------------------------------------------------------------------------------------------------------------
# 6. YAML cleanup
# --------------------------------------------------------------------------------------------------------------

function Remove-ComponentKey {
    # Removes '<Key>: ...' lines only inside the YAML blocks of components whose type tag matches $TagPattern.
    # Returns @(newText, removedCount).
    param([string] $Text, [string] $TagPattern, [string] $Key)
    $lines = [regex]::Split($Text, '(?<=\n)')
    $sb = New-Object System.Text.StringBuilder
    $blockIndent = -1; $removed = 0
    foreach ($line in $lines) {
        $trimmed = $line.TrimEnd("`r", "`n")
        if ($trimmed.Trim().Length -gt 0) {
            $indent = $trimmed.Length - $trimmed.TrimStart(' ').Length
            if ($blockIndent -ge 0 -and $indent -le $blockIndent) { $blockIndent = -1 }
            if ($trimmed -match "^\s*- !$TagPattern,") { $blockIndent = $indent }
            elseif ($blockIndent -ge 0 -and $trimmed -match "^\s*$([regex]::Escape($Key)):(\s|$)" -and $indent -eq $blockIndent + 2) { $removed++; continue }
        }
        [void]$sb.Append($line)
    }
    return @($sb.ToString(), $removed)
}

if ($CleanObsoleteYaml) {
    foreach ($f in $yamlFiles) {
        $file = Read-TextFile $f.FullName
        $text = $file.Text
        # Light.ShadowBias is obsolete and ignored: drop it from light components only.
        $r = Remove-ComponentKey $text 'Evergine\.[\w.]+Light' 'ShadowBias'
        $text = $r[0]
        if ($r[1] -gt 0) { Add-Finding 'Info' 'yaml-shadowbias-removed' (Get-RelativePath $f.FullName) 0 "Removed $($r[1]) obsolete ShadowBias key(s)." }
        foreach ($m in [regex]::Matches($text, '!Evergine\.Components\.Graphics3D\.(EnvironmentComponent|ShadowMapComponent),')) { Add-Finding 'Warning' 'manual-edit-required' (Get-RelativePath $f.FullName) (Get-LineNumber $text $m.Index) "$($m.Groups[1].Value) no longer exists; move its values to the scene manager and delete the block." }
        # SpatialMapping.MaskBits was removed (collision filtering is the PhysicsManager collision matrix now).
        $text = (Remove-ComponentKey $text 'Evergine\.Components\.XR\.SpatialMapping' 'MaskBits')[0]
        Save-TextFile $file $text 'yaml' | Out-Null
    }
}

# --------------------------------------------------------------------------------------------------------------
# 6b. Custom effects that use the Shadow library (signatures changed; old calls may compile and render wrong shadows)
# --------------------------------------------------------------------------------------------------------------

foreach ($f in @(Get-ProjectFiles '*.fx', '*.fxh', '*.hlsl')) {
    $t = Get-Content -Raw $f.FullName
    if (-not $t) { continue }
    foreach ($m in [regex]::Matches($t, '\b(DirectionalLightShadow|PointLightShadow|SpotLightShadow|GetCascadeFromDepth|ShadowCascade|CascadeSplits)\b')) {
        Add-Finding 'Warning' 'shader-shadow-library' (Get-RelativePath $f.FullName) (Get-LineNumber $t $m.Index) "$($m.Groups[1].Value): the Shadow effect library changed (the shadow functions take the geometric normal instead of NoL, cascades are selected with SelectDirectionalCascade, CascadeSplits is a float4); see the migration guide."
    }
}

# --------------------------------------------------------------------------------------------------------------
# 7. Feeds
# --------------------------------------------------------------------------------------------------------------

$configDir = if ($hasWeproj) { Split-Path $weprojFiles[0].FullName } else { $script:Root }
$nugetConfig = Get-ChildItem $configDir -File | Where-Object { $_.Name -ieq 'nuget.config' } | Select-Object -First 1
if ($nugetConfig) {
    $file = Read-TextFile $nugetConfig.FullName
    $text = $file.Text
    # Only <packageSources> entries; relative paths are relative to the nuget.config folder.
    $sourcesSection = [regex]::Match($text, '(?s)<packageSources>.*?</packageSources>').Value
    foreach ($m in [regex]::Matches($sourcesSection, '(?m)^[ \t]*<add\s+key="([^"]+)"\s+value="([^"]+)"[^>]*/>[ \t]*\r?\n?')) {
        $value = $m.Groups[2].Value
        $localPath = if ([System.IO.Path]::IsPathRooted($value)) { $value } else { Join-Path $configDir $value }
        if ($value -notmatch '^https?://' -and $value -notmatch '\$\(' -and -not (Test-Path $localPath)) {
            $text = $text.Replace($m.Value, '')
            Add-Finding 'Info' 'nuget-local-source-removed' (Get-RelativePath $nugetConfig.FullName) 0 "Removed package source '$($m.Groups[1].Value)' ($value does not exist on this machine)."
        }
    }
    if ($isNightly -and $text -notmatch [regex]::Escape($script:NightlyNuGetFeed)) {
        $text = [regex]::Replace($text, '(?m)^([ \t]*)</packageSources>', "`$1  <add key=`"Evergine Nightly`" value=`"$($script:NightlyNuGetFeed)`" />$($file.Eol)`$1</packageSources>", 1)
        Add-Finding 'Info' 'nuget-nightly-feed-added' (Get-RelativePath $nugetConfig.FullName) 0 'Added the Evergine Nightly feed.'
    }
    Save-TextFile $file $text 'nuget.config' | Out-Null
} elseif ($isNightly) {
    $path = Join-Path $configDir 'nuget.config'
    $content = "<?xml version=`"1.0`" encoding=`"utf-8`"?>`r`n<configuration>`r`n  <packageSources>`r`n    <add key=`"nuget.org`" value=`"https://api.nuget.org/v3/index.json`" />`r`n    <add key=`"Evergine Nightly`" value=`"$($script:NightlyNuGetFeed)`" />`r`n  </packageSources>`r`n</configuration>`r`n"
    $script:ChangeCount++; $script:ChangedFiles.Add((Get-RelativePath $path))
    if ($Apply) { [System.IO.File]::WriteAllText($path, $content, (New-Object System.Text.UTF8Encoding($true))) }
    Add-Finding 'Info' 'nuget-config-created' (Get-RelativePath $path) 0 'Created nuget.config with nuget.org and the Evergine Nightly feed.'
}

if ($hasWeproj) {
    $evConfigPath = Join-Path $configDir 'Evergine.config'
    $sources = [ordered]@{}
    $existing = $null
    $evConfigChanged = $false
    if (Test-Path $evConfigPath) {
        $existing = Read-TextFile $evConfigPath
        try { $json = $existing.Text | ConvertFrom-Json } catch { $json = $null }
        if ($json -and $json.PSObject.Properties['Sources']) {
            foreach ($p in $json.Sources.PSObject.Properties) {
                $localPath = if ([System.IO.Path]::IsPathRooted([string]$p.Value)) { [string]$p.Value } else { Join-Path $configDir ([string]$p.Value) }
                if ($p.Value -notmatch '^https?://' -and -not (Test-Path $localPath)) { $evConfigChanged = $true; Add-Finding 'Info' 'evergine-local-source-removed' 'Evergine.config' 0 "Removed source '$($p.Name)' ($($p.Value) does not exist on this machine)."; continue }
                $sources[$p.Name] = $p.Value
            }
        }
    }
    if (-not $sources.Contains('Evergine')) { $sources['Evergine'] = $script:StableBlobSource; $evConfigChanged = $true }
    if ($isNightly -and -not ($sources.Values -contains $script:NightlyBlobSource)) { $sources['Evergine Nightly'] = $script:NightlyBlobSource; $evConfigChanged = $true }
    $newJson = [pscustomobject]@{ Sources = [pscustomobject]$sources } | ConvertTo-Json
    if ($existing) { if ($evConfigChanged) { Save-TextFile $existing $newJson 'Evergine.config' | Out-Null } }
    elseif (-not $isNightly) { }   # Stable versions resolve through Evergine Studio's default sources; no file needed.
    else {
        $script:ChangeCount++; $script:ChangedFiles.Add((Get-RelativePath $evConfigPath))
        if ($Apply) { [System.IO.File]::WriteAllText($evConfigPath, $newJson, (New-Object System.Text.UTF8Encoding($false))) }
        Add-Finding 'Info' 'evergine-config-created' 'Evergine.config' 0 'Created Evergine.config with the stable and nightly sources.'
    }
}

# --------------------------------------------------------------------------------------------------------------
# 8. DirectX12 switch (code side)
# --------------------------------------------------------------------------------------------------------------

if ($SwitchWindowsProfileToDirectX12) {
    foreach ($f in $csFiles | Where-Object { $_.FullName -match '[\\/][^\\/]+\.Windows[\\/]Program\.cs$' }) {
        $file = Read-TextFile $f.FullName
        $text = $file.Text -replace 'Evergine\.DirectX11\.DX11GraphicsContext', 'Evergine.DirectX12.DX12GraphicsContext' -replace '(CreateWindow\("[^"]*) - DX11"', '$1 - DX12"'
        Save-TextFile $file $text 'DirectX12' | Out-Null
    }

    # The old 'Windows.DirectX12' launcher becomes 'Windows.DirectX11' (Studio's Windows_DirectX11 template), so two
    # launchers do not target the same API and DirectX11 keeps one.
    foreach ($w in $weprojFiles) {
        $file = Read-TextFile $w.FullName
        $text = [regex]::Replace($file.Text, '(?m)(GraphicsBackend: )DirectX12(\r?\n[ \t]{4}LauncherType: )DirectX12(\r?\n[ \t]{4}Name: Windows\.)DirectX12(?=\r?$)', '${1}DirectX11${2}DirectX11${3}DirectX11')
        if (-not (Save-TextFile $file $text 'DirectX11 launcher')) { continue }
        $name = $w.BaseName; $old = "$name.Windows.DirectX12"; $new = "$name.Windows.DirectX11"
        $oldDir = Join-Path $w.DirectoryName $old; $oldSln = Join-Path $w.DirectoryName "$old.sln"
        Add-Finding 'Info' 'dx12-launcher-to-dx11' (Get-RelativePath $w.FullName) 0 "Profile Windows.DirectX12 and $old became Windows.DirectX11 and $new."
        $targets = @(Get-ChildItem $oldDir -Recurse -File -Include '*.csproj', '*.cs' -ErrorAction SilentlyContinue | Where-Object FullName -notmatch '[\\/](bin|obj)[\\/]') + @(Get-Item $oldSln -ErrorAction SilentlyContinue)
        foreach ($t in $targets) {
            $tf = Read-TextFile $t.FullName
            $n = $tf.Text.Replace($old, $new) -replace 'Include="Evergine\.DirectX12"', 'Include="Evergine.DirectX11"' -replace 'Evergine\.DirectX12\.DX12GraphicsContext', 'Evergine.DirectX11.DX11GraphicsContext' -replace '(CreateWindow\("[^"]*) - DX12"', '$1 - DX11"'
            Save-TextFile $tf $n 'DirectX11 launcher' | Out-Null
        }
        foreach ($md in Get-ProjectFiles -Include '*.md') {
            $tf = Read-TextFile $md.FullName
            $n = -join ($tf.Text -split '(?<=\n)' | ForEach-Object {
                if ($_ -match "``$([regex]::Escape($name))\.Windows``") { $_ -replace 'DirectX 11', 'DirectX 12' }
                elseif ($_.Contains($old)) { $_.Replace($old, $new) -replace 'DirectX 12', 'DirectX 11' }
                else { $_ }
            })
            Save-TextFile $tf $n 'DirectX11 launcher' | Out-Null
        }
        if ($Apply) {
            if (Test-Path (Join-Path $oldDir "$old.csproj")) { Move-Item (Join-Path $oldDir "$old.csproj") (Join-Path $oldDir "$new.csproj") }
            if (Test-Path $oldDir) { Move-Item $oldDir (Join-Path $w.DirectoryName $new) }
            if (Test-Path $oldSln) { Move-Item $oldSln (Join-Path $w.DirectoryName "$new.sln") }
        }
    }
}

# --------------------------------------------------------------------------------------------------------------
# Report
# --------------------------------------------------------------------------------------------------------------

$warnings = @($script:Findings | Where-Object Severity -eq 'Warning')
$report = [pscustomobject]@{
    Tool            = 'Update-EvergineProject'
    ProjectPath     = $script:Root
    DetectedVersion = $detectedVersion
    TargetVersion   = $TargetVersion
    Mode            = $(if ($Apply) { 'Apply' } else { 'DryRun' })
    GeneratedAt     = (Get-Date).ToString('o')
    UsesPhysics     = $usesPhysics
    ScannedFiles    = $script:ScannedFiles
    ChangedFiles    = @($script:ChangedFiles)
    Changes         = $script:ChangeCount
    BackupPath      = $script:Backup
    Findings        = @($script:Findings)
}
if ($ReportPath) {
    $rp = if ([System.IO.Path]::IsPathRooted($ReportPath)) { $ReportPath } else { Join-Path $script:Root $ReportPath }
    New-Item -ItemType Directory -Force (Split-Path $rp) | Out-Null
    $report | ConvertTo-Json -Depth 6 | Set-Content -Path $rp -Encoding utf8
}

Write-Host ''
Write-Host "Scanned $($script:ScannedFiles) files, $($script:ChangeCount) change(s) in $($script:ChangedFiles.Count) file(s); $($warnings.Count) warning(s), $($script:Findings.Count - $warnings.Count) info."
if ($script:Findings.Count -gt 0) { $script:Findings | Sort-Object @{ Expression = { $_.Severity -ne 'Warning' } }, File | Format-Table Severity, Code, File, Line, Message -AutoSize -Wrap | Out-String -Width 220 | Write-Host }
if (-not $Apply) { Write-Host 'No files were modified. Run again with -Apply.' }
Write-Output $report
exit $(if ($warnings.Count -gt 0) { 2 } else { 0 })
