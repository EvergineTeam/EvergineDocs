#Requires -Version 5.1
<#
.SYNOPSIS
    Upgrades .NET target framework versions, NuGet package references, and Evergine
    asset files as part of a solution migration.

.DESCRIPTION
    Scans all matching files under the given root path and applies a configurable set of
    upgrades:
      - Target Framework Moniker (TFM) replacements  (e.g. net8.0 -> net10.0)
      - NuGet package version replacements            (currently empty – add entries below)
      - Evergine render layer files (.werl)           (e.g. reverse-Z DepthFunction fix)
    The script is designed to be extended: additional file-type processors can be
    plugged in via the $FileProcessors collection at the bottom of this file.

.PARAMETER RootPath
    Root directory to search. All .csproj files found recursively will be processed.
    Defaults to the current directory.

.PARAMETER DryRun
    When specified, no files are written. The script only reports what would change.

.PARAMETER BackupOriginals
    When specified, a ".bak" copy of each modified file is created before writing.

.EXAMPLE
    .\migration-2026.5.26.ps1 -RootPath "C:\Projects\MySolution"

.EXAMPLE
    .\migration-2026.5.26.ps1 -RootPath "C:\Projects" -DryRun

.EXAMPLE
    .\migration-2026.5.26.ps1 -RootPath "C:\Projects\MySolution" -BackupOriginals
#>

[CmdletBinding()]
param (
    [Parameter(Position = 0)]
    [string] $RootPath = (Get-Location).Path,

    [switch] $DryRun,

    [switch] $BackupOriginals,

    [string] $OldEvergineVersion = '',
    [string] $NewEvergineVersion = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 1 – TARGET FRAMEWORK UPGRADES
# Each entry is a hashtable with:
#   Pattern     – regex that matches the OLD TFM value inside <TargetFramework(s)>
#   Replacement – the string that replaces the matched portion
#
# The regex uses a named group (?<suffix>...) to preserve any platform/OS suffix
# that follows the version number (e.g. -windows, -android, -ios, -maccatalyst …).
# ──────────────────────────────────────────────────────────────────────────────
$TfmUpgrades = @(
    @{
        Description = 'net8.0  ->  net10.0  (all variants)'
        # Matches: net8.0, net8.0-windows, net8.0-windows10.0.19041.0,
        #          net8.0-android, net8.0-ios, etc.
        Pattern     = 'net8\.0(?<suffix>[-][^\s<;]*)?'
        Replacement = 'net10.0${suffix}'
    }
    @{
        Description = 'net9.0  ->  net10.0  (all variants)'
        # Matches: net9.0, net9.0-android, net9.0-ios, net9.0-maccatalyst, etc.
        Pattern     = 'net9\.0(?<suffix>[-][^\s<;]*)?'
        Replacement = 'net10.0${suffix}'
    }

    # ── Add further TFM upgrades here, for example: ──────────────────────────
)

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 2 – NUGET PACKAGE VERSION UPGRADES
# Each entry is a hashtable with:
#   PackageId   – exact package ID (case-insensitive comparison)
#   OldVersion  – regex that matches the version string to replace
#   NewVersion  – literal replacement version string
#
# Example (commented out – uncomment and adapt as needed):
# ──────────────────────────────────────────────────────────────────────────────
$NugetUpgrades = @(
    @{
        Description = 'Evergine.LibBulletc.Natives 2023.11.28.20 -> 2025.8.29.27'
        PackageId   = 'Evergine.LibBulletc.Natives'
        OldVersion  = '2023\.11\.28\.20'
        NewVersion  = '2025.8.29.27'
    }
    @{
        Description = 'Microsoft.AspNetCore.Components.WebAssembly 8.0.20 -> 10.0.8'
        PackageId   = 'Microsoft.AspNetCore.Components.WebAssembly'
        OldVersion  = '8\.0\.20'
        NewVersion  = '10.0.8'
    }
    @{
        Description = 'Microsoft.AspNetCore.Components.WebAssembly.DevServer 8.0.20 -> 10.0.8'
        PackageId   = 'Microsoft.AspNetCore.Components.WebAssembly.DevServer'
        OldVersion  = '8\.0\.20'
        NewVersion  = '10.0.8'
    }
    @{
        Description = 'Microsoft.AspNetCore.Components.WebAssembly.Server 8.0.20 -> 10.0.8'
        PackageId   = 'Microsoft.AspNetCore.Components.WebAssembly.Server'
        OldVersion  = '8\.0\.20'
        NewVersion  = '10.0.8'
    }
    @{
        Description = 'Microsoft.TypeScript.MSBuild 5.9.2 -> 6.0.3'
        PackageId   = 'Microsoft.TypeScript.MSBuild'
        OldVersion  = '5\.9\.2'
        NewVersion  = '6.0.3'
    }
    @{
        Description = 'Microsoft.Extensions.Logging.Debug 8.0.0 -> 10.0.8'
        PackageId   = 'Microsoft.Extensions.Logging.Debug'
        OldVersion  = '8\.0\.0'
        NewVersion  = '10.0.8'
    }

    # @{
    #     Description = 'Newtonsoft.Json 13.x -> 14.x'
    #     PackageId   = 'Newtonsoft.Json'
    #     OldVersion  = '13\.\d+\.\d+'
    #     NewVersion  = '14.0.0'
    # }
    # @{
    #     Description = 'Microsoft.EntityFrameworkCore 8.x -> 10.x'
    #     PackageId   = 'Microsoft.EntityFrameworkCore'
    #     OldVersion  = '8\.\d+\.\d+'
    #     NewVersion  = '10.0.0'
    # }
)

# ── Dynamic Evergine NuGet upgrade (from -OldEvergineVersion / -NewEvergineVersion) ──────────
if ($OldEvergineVersion -and $NewEvergineVersion) {
    $NugetUpgrades += @(
        @{
            Description = "Evergine.* $OldEvergineVersion  ->  $NewEvergineVersion"
            PackageId   = 'Evergine\.[^"]+'
            OldVersion  = [regex]::Escape($OldEvergineVersion)
            NewVersion  = $NewEvergineVersion
            IsPattern   = $true
        }
    )
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 3 – EVERGINE RENDER LAYER (.werl) UPGRADES
# Each entry is a hashtable with:
#   YamlKey     – the YAML key whose value will be replaced (e.g. 'DepthFunction')
#   OldValue    – the exact old value string
#   NewValue    – the exact new value string
#   Description – human-readable reason shown in the change log
#
# These files are plain YAML; replacements are done on the key: value line to
# avoid accidental hits on unrelated lines that share the same value string.
# ──────────────────────────────────────────────────────────────────────────────
$WerlUpgrades = @(
    @{
        # Reverse-Z projection: the depth buffer is now filled in the opposite
        # direction (1.0 = near, 0.0 = far), so fragments closer to the camera
        # have a GREATER depth value. GreaterEqual must replace LessEqual for
        # depth testing to behave correctly.
        Description = 'Reverse-Z: DepthFunction LessEqual  ->  GreaterEqual'
        YamlKey     = 'DepthFunction'
        OldValue    = 'LessEqual'
        NewValue    = 'GreaterEqual'
    }

    # ── Add further .werl upgrades here ──────────────────────────────────────
    # @{
    #     Description = 'Example: rename a blend operation value'
    #     YamlKey     = 'BlendOperationColor'
    #     OldValue    = 'OldEnumValue'
    #     NewValue    = 'NewEnumValue'
    # }
)

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 3b – WEB PROJECT FILE REPLACEMENTS
# Copies files/folders from the 'contexto' directory into matching project
# folders found under RootPath.
#
# Each rule:
#   FolderNameRegex – regex matched against the FOLDER NAME (not full path)
#   Description     – human-readable label shown in the output
#   Items           – list of copy operations:
#     Source   – path relative to the script directory (where the template lives)
#     Target   – relative path inside the matched project folder
#     IsFolder – $true to replace an entire folder, $false for a single file
# ──────────────────────────────────────────────────────────────────────────────
$DirectoryReplacements = @(
    @{
        Description     = 'Web frontend: replace tsconfig.json and ts/ folder'
        # Matches: MyProject.Web, MyProject.WebGPU  (NOT .Web.Server etc.)
        FolderNameRegex = '\.(Web|WebGPU)$'
        Items = @(
            @{ Source = 'resources\web\tsconfig.json'; Target = 'tsconfig.json'; IsFolder = $false }
            @{ Source = 'resources\web\ts';            Target = 'ts';            IsFolder = $true  }
        )
    }
    @{
        Description     = 'Web server: replace Program.cs'
        # Matches: MyProject.Web.Server, MyProject.WebGPU.Server
        FolderNameRegex = '\.(Web|WebGPU)\.Server$'
        Items = @(
            @{ Source = 'resources\web\Program.cs'; Target = 'Program.cs'; IsFolder = $false }
        )
    }

    # ── Add further directory replacement rules here ──────────────────────────
    # @{
    #     Description     = 'Example rule'
    #     FolderNameRegex = '\.SomePattern$'
    #     Items = @(
    #         @{ Source = 'contexto\some\file.txt'; Target = 'file.txt'; IsFolder = $false }
    #     )
    # }
)

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 4 – PROCESSOR FUNCTIONS
# Each processor receives the raw file content (string) and returns the
# (potentially modified) content plus a list of human-readable change
# descriptions so the caller can report them.
# ──────────────────────────────────────────────────────────────────────────────

function Invoke-TfmProcessor {
    <#
    .SYNOPSIS
        Replaces Target Framework Monikers inside <TargetFramework> /
        <TargetFrameworks> elements AND inside Condition attributes that
        compare against $(TargetFramework)  (e.g. Condition="'$(TargetFramework)' == 'net9.0-android'").
    #>
    param (
        [string] $Content,
        [string] $FilePath      # for diagnostic messages only
    )

    $changes = [System.Collections.Generic.List[string]]::new()
    $result  = $Content

    foreach ($upgrade in $TfmUpgrades) {
        # ── XML element: <TargetFramework(s)>…</TargetFramework(s)> ──────────
        # Handles both single and semicolon-separated lists, and opening tags
        # that carry attributes (e.g. Condition="…").
        $xmlPattern = "(?<=<TargetFrameworks?(?:\s[^>]*)?>)([^<]*)(?=</TargetFrameworks?>)"

        $result = [regex]::Replace($result, $xmlPattern, {
            param($xmlMatch)

            $innerValue  = $xmlMatch.Value
            $newInner    = [regex]::Replace($innerValue, $upgrade.Pattern, $upgrade.Replacement)

            if ($newInner -ne $innerValue) {
                $changes.Add("  TFM  : '$innerValue'  ->  '$newInner'  [$($upgrade.Description)]")
            }

            return $newInner
        })

        # ── Condition attributes referencing $(TargetFramework) ──────────────
        # Two-pass: find the whole Condition="…$(TargetFramework)…" attribute,
        # then replace any single-quoted TFM value inside it.
        $condAttrPattern = '(?i)(Condition\s*=\s*"[^"]*\$\(TargetFramework\)[^"]*")'

        $result = [regex]::Replace($result, $condAttrPattern, {
            param($attrMatch)
            $attr = $attrMatch.Value

            $newAttr = [regex]::Replace($attr, "'(net\d+\.\d+[-\w.]*)'", {
                param($tfmMatch)
                $tfmValue = $tfmMatch.Groups[1].Value
                $newTfm   = [regex]::Replace($tfmValue, $upgrade.Pattern, $upgrade.Replacement)
                if ($newTfm -ne $tfmValue) {
                    $changes.Add("  TFM  : (condition) '$tfmValue'  ->  '$newTfm'  [$($upgrade.Description)]")
                }
                return "'$newTfm'"
            })

            return $newAttr
        })
    }

    return [PSCustomObject]@{
        Content = $result
        Changes = $changes
    }
}

function Invoke-NugetProcessor {
    <#
    .SYNOPSIS
        Replaces NuGet package versions inside <PackageReference> elements.
        Handles both attribute style and child-element style:
          <PackageReference Include="Foo" Version="1.0.0" />
          <PackageReference Include="Foo"><Version>1.0.0</Version></PackageReference>
    #>
    param (
        [string] $Content,
        [string] $FilePath      # for diagnostic messages only
    )

    $changes = [System.Collections.Generic.List[string]]::new()
    $result  = $Content

    foreach ($upgrade in $NugetUpgrades) {
        $pkgId = if ($upgrade['IsPattern']) { $upgrade.PackageId } else { [regex]::Escape($upgrade.PackageId) }

        # ── Attribute style: Version="..." ───────────────────────────────────
        $attrPattern = "(?i)(<PackageReference\s[^>]*Include=""$pkgId""[^>]*\sVersion="")($($upgrade.OldVersion))("")"

        $result = [regex]::Replace($result, $attrPattern, {
            param($m)
            $changes.Add("  NuGet: $($upgrade.PackageId) '$($m.Groups[2].Value)'  ->  '$($upgrade.NewVersion)'  [$($upgrade.Description)]")
            return "$($m.Groups[1].Value)$($upgrade.NewVersion)$($m.Groups[3].Value)"
        }, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)

        # ── Child element style: <Version>...</Version> ───────────────────────
        # Two-pass: first locate the PackageReference block, then fix its Version child.
        $blockPattern = "(?is)(<PackageReference\s[^>]*Include=""$pkgId"".*?</PackageReference>)"

        $result = [regex]::Replace($result, $blockPattern, {
            param($blockMatch)
            $block    = $blockMatch.Value
            $newBlock = [regex]::Replace($block,
                "(?i)(<Version>)($($upgrade.OldVersion))(</Version>)", {
                    param($vm)
                    $changes.Add("  NuGet: $($upgrade.PackageId) '$($vm.Groups[2].Value)'  ->  '$($upgrade.NewVersion)'  [$($upgrade.Description)]")
                    return "$($vm.Groups[1].Value)$($upgrade.NewVersion)$($vm.Groups[3].Value)"
                }, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            return $newBlock
        }, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase -bor
           [System.Text.RegularExpressions.RegexOptions]::Singleline)
    }

    return [PSCustomObject]@{
        Content = $result
        Changes = $changes
    }
}

function Invoke-WerlProcessor {
    <#
    .SYNOPSIS
        Applies upgrades to Evergine render layer asset files (.werl).
        These are plain YAML files. Each upgrade targets a specific key: value
        line so only the intended field is rewritten.
    #>
    param (
        [string] $Content,
        [string] $FilePath      # for diagnostic messages only
    )

    $changes = [System.Collections.Generic.List[string]]::new()
    $result  = $Content

    foreach ($upgrade in $WerlUpgrades) {
        # Match the YAML line that contains exactly "  Key: OldValue"
        # The leading whitespace is captured and preserved so indentation is kept.
        $pattern = "(?m)^(?<indent>\s*)$([regex]::Escape($upgrade.YamlKey)):\s*$([regex]::Escape($upgrade.OldValue))\s*$"

        $result = [regex]::Replace($result, $pattern, {
            param($m)
            $changes.Add("  WERL : $($upgrade.YamlKey): '$($upgrade.OldValue)'  ->  '$($upgrade.NewValue)'  [$($upgrade.Description)]")
            return "$($m.Groups['indent'].Value)$($upgrade.YamlKey): $($upgrade.NewValue)"
        })
    }

    return [PSCustomObject]@{
        Content = $result
        Changes = $changes
    }
}

function Invoke-WeprojProcessor {
    <#
    .SYNOPSIS
        Updates Evergine package versions inside Evergine project files (.weproj).
        Requires -OldEvergineVersion and -NewEvergineVersion to be specified.
        Processes line by line: tracks when inside an 'Evergine.*' package block
        and replaces any 'Version: OLD' line found within it, regardless of the
        number or order of other fields between Id and Version.
    #>
    param (
        [string] $Content,
        [string] $FilePath      # for diagnostic messages only
    )

    $changes = [System.Collections.Generic.List[string]]::new()

    if (-not $OldEvergineVersion -or -not $NewEvergineVersion) {
        return [PSCustomObject]@{ Content = $Content; Changes = $changes }
    }

    $oldVerEscaped = [regex]::Escape($OldEvergineVersion)

    # Detect and preserve the file's line ending (CRLF or LF).
    $lineEnding = if ($Content -match '\r\n') { "`r`n" } else { "`n" }
    $lines      = $Content -split '\r?\n'

    $inEverginePackage = $false
    $resultLines       = [System.Collections.Generic.List[string]]::new()

    foreach ($line in $lines) {
        # Every '- Id:' entry starts a new package; update context accordingly.
        if ($line -match '^\s*-\s*Id:') {
            $inEverginePackage = $line -match '^\s*-\s*Id:\s*Evergine\.'
        }

        if ($inEverginePackage -and $line -match "^\s*Version:\s*$oldVerEscaped\s*$") {
            $resultLines.Add($line.Replace($OldEvergineVersion, $NewEvergineVersion))
            $changes.Add("  WEPROJ: Evergine package Version '$OldEvergineVersion'  ->  '$NewEvergineVersion'")
        } else {
            $resultLines.Add($line)
        }
    }

    return [PSCustomObject]@{
        Content = $resultLines -join $lineEnding
        Changes = $changes
    }
}
# ──────────────────────────────────────────────────────────────────────────────
# SECTION 5 – FILE PROCESSORS REGISTRY
# Maps a file extension (glob pattern used by Get-ChildItem -Filter) to an
# ordered list of processor functions to run against that file type.
#
# To add support for a new file format in the future, simply:
#   1. Write a new processor function (following the same param/return contract).
#   2. Add a new entry to $FileProcessors below.
# ──────────────────────────────────────────────────────────────────────────────
$FileProcessors = [ordered]@{

    '*.csproj' = @(
        ${function:Invoke-TfmProcessor}
        ${function:Invoke-NugetProcessor}

        # ── Placeholder for future .csproj processors ─────────────────────
        # ${function:Invoke-SomeOtherCsprojProcessor}
    )

    # Evergine render layer assets (YAML format).
    # Applies reverse-Z depth function fix and any other registered .werl upgrades.
    '*.werl' = @(
        ${function:Invoke-WerlProcessor}
    )

    # Evergine project files (.weproj). Updates Evergine package versions
    # when -OldEvergineVersion / -NewEvergineVersion are supplied.
    '*.weproj' = @(
        ${function:Invoke-WeprojProcessor}
    )

    # ── Placeholder entries for future file types ──────────────────────────
    # '*.props' = @(
    #     ${function:Invoke-TfmProcessor}
    #     ${function:Invoke-NugetProcessor}
    # )
    # '*.targets' = @(
    #     ${function:Invoke-NugetProcessor}
    # )
    # '*.json' = @(
    #     ${function:Invoke-GlobalJsonProcessor}   # not implemented yet
    # )
}

# ──────────────────────────────────────────────────────────────────────────────
# SECTION 6 – MAIN EXECUTION
# ──────────────────────────────────────────────────────────────────────────────

function Write-Header {
    param([string] $Text)
    $line = '─' * 72
    Write-Host ""
    Write-Host $line -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host $line -ForegroundColor Cyan
}

function Write-Summary {
    param(
        [int] $TotalFiles,
        [int] $ModifiedFiles,
        [int] $SkippedFiles,
        [bool] $IsDryRun
    )

    $label = if ($IsDryRun) { ' [DRY RUN – no files were written]' } else { '' }
    Write-Host ""
    Write-Host "──────────────────────────────────────────────────────────────────────────" -ForegroundColor Cyan
    Write-Host "  Summary$label" -ForegroundColor Cyan
    Write-Host "    Files scanned  : $TotalFiles"
    Write-Host "    Files changed  : $ModifiedFiles" -ForegroundColor ($ModifiedFiles -gt 0 ? 'Yellow' : 'Gray')
    Write-Host "    Files skipped  : $SkippedFiles"
    Write-Host "──────────────────────────────────────────────────────────────────────────" -ForegroundColor Cyan
    Write-Host ""
}

# ── Validate root path ────────────────────────────────────────────────────────
if (-not (Test-Path -LiteralPath $RootPath -PathType Container)) {
    Write-Error "RootPath '$RootPath' does not exist or is not a directory."
    exit 1
}

Write-Header "migration-2026.5.26$(if ($DryRun) { '  [DRY RUN]' })"
Write-Host "  Root path : $RootPath"
Write-Host "  Dry run   : $DryRun"
Write-Host "  Backups   : $BackupOriginals"
Write-Host "  Evergine  : $(if ($OldEvergineVersion) { "$OldEvergineVersion  ->  $NewEvergineVersion" } else { '(not specified)' })"

$totalFiles    = 0
$modifiedFiles = 0
$skippedFiles  = 0

foreach ($filter in $FileProcessors.Keys) {

    $processors = $FileProcessors[$filter]
    $files      = @(Get-ChildItem -Path $RootPath -Filter $filter -Recurse -File)

    if (-not $files) {
        Write-Host ""
        Write-Host "  No '$filter' files found under '$RootPath'." -ForegroundColor DarkGray
        continue
    }

    Write-Host ""
    Write-Host "  Processing '$filter' files ($($files.Count) found) …" -ForegroundColor White

    foreach ($file in $files) {
        $totalFiles++

        # Read with the file's own encoding; -Raw preserves line endings exactly.
        $originalContent = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8
        $currentContent  = $originalContent
        $allChanges      = [System.Collections.Generic.List[string]]::new()

        # Run every registered processor in order.
        foreach ($processor in $processors) {
            $processorResult = & $processor -Content $currentContent -FilePath $file.FullName
            $currentContent  = $processorResult.Content
            foreach ($change in $processorResult.Changes) { $allChanges.Add($change) }
        }

        if ($currentContent -eq $originalContent) {
            $skippedFiles++
            Write-Host "  [SKIP]    $($file.FullName)" -ForegroundColor DarkGray
            continue
        }

        # Report changes.
        $modifiedFiles++
        $verb = if ($DryRun) { '[DRY RUN]' } else { '[UPDATED]' }
        Write-Host "  $verb $($file.FullName)" -ForegroundColor Yellow
        foreach ($change in $allChanges) {
            Write-Host $change -ForegroundColor Green
        }

        if (-not $DryRun) {
            # Optionally backup the original file.
            if ($BackupOriginals) {
                $backupPath = "$($file.FullName).bak"
                Copy-Item -LiteralPath $file.FullName -Destination $backupPath -Force
                Write-Host "  [BACKUP]  $backupPath" -ForegroundColor DarkGray
            }

            # Write back, preserving UTF-8 without BOM (standard for .csproj).
            $utf8NoBom = [System.Text.UTF8Encoding]::new($false)
            [System.IO.File]::WriteAllText($file.FullName, $currentContent, $utf8NoBom)
        }
    }
}

Write-Summary -TotalFiles $totalFiles -ModifiedFiles $modifiedFiles `
              -SkippedFiles $skippedFiles -IsDryRun $DryRun.IsPresent

# ── Directory-scoped file replacements ───────────────────────────────────────
if (@($DirectoryReplacements).Count -gt 0) {

    Write-Header "Web project file replacements$(if ($DryRun) { '  [DRY RUN]' })"

    foreach ($rule in $DirectoryReplacements) {

        $matchedFolders = @(Get-ChildItem -Path $RootPath -Directory -Recurse |
            Where-Object { $_.Name -match $rule.FolderNameRegex })

        if (-not $matchedFolders) {
            Write-Host ""
            Write-Host "  No folders matching '$($rule.FolderNameRegex)'  [$($rule.Description)]." -ForegroundColor DarkGray
            continue
        }

        Write-Host ""
        Write-Host "  $($rule.Description) – $($matchedFolders.Count) folder(s) matched …" -ForegroundColor White

        foreach ($folder in $matchedFolders) {
            foreach ($item in $rule.Items) {
                $sourcePath = Join-Path $PSScriptRoot $item['Source']
                $targetPath = Join-Path $folder.FullName $item['Target']

                if (-not (Test-Path -LiteralPath $sourcePath)) {
                    Write-Warning "  [MISSING TEMPLATE] $sourcePath"
                    continue
                }

                $verb = if ($DryRun) { '[DRY RUN]' } else { '[REPLACE]' }
                Write-Host "  $verb $targetPath" -ForegroundColor Yellow

                if (-not $DryRun) {
                    if ($item['IsFolder']) {
                        if ($BackupOriginals -and (Test-Path -LiteralPath $targetPath)) {
                            $backupPath = "$targetPath.bak"
                            Copy-Item -LiteralPath $targetPath -Destination $backupPath -Recurse -Force
                            Write-Host "  [BACKUP]  $backupPath" -ForegroundColor DarkGray
                        }
                        if (Test-Path -LiteralPath $targetPath) {
                            Remove-Item -LiteralPath $targetPath -Recurse -Force
                        }
                        Copy-Item -LiteralPath $sourcePath -Destination $targetPath -Recurse
                    } else {
                        if ($BackupOriginals -and (Test-Path -LiteralPath $targetPath)) {
                            Copy-Item -LiteralPath $targetPath -Destination "$targetPath.bak" -Force
                            Write-Host "  [BACKUP]  $targetPath.bak" -ForegroundColor DarkGray
                        }
                        Copy-Item -LiteralPath $sourcePath -Destination $targetPath -Force
                    }
                }
            }
        }
    }
}
